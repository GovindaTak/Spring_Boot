package com.app.exception;

public class AppointmentException extends Exception {


	public AppointmentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
