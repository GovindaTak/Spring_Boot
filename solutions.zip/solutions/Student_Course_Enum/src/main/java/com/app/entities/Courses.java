package com.app.entities;

public enum Courses {

	DAC(78),IOT(70),DBDA(60);
	private double minScore;

	private Courses(double minScore) {
		this.minScore = minScore;
	}

	public double getMinScore() {
		return minScore;
	}

	public void setMinScore(double minScore) {
		this.minScore = minScore;
	}
	
}
